# WeatherApp

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 11.2.9.

## Development server

Start the service locally by executing the following command.

After downloading folder from git respository, go to below mentioned folder path:

cd /home/weatherForecast/weather-app

Run npm i - command to install angular packages.

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.
If you already using port 4200 for another project you can use ng serve --port 4100

# We can include more features/improvise UI‌ into current developed weather screen
1. code can be make it more dynamic in tearms of displaying bottom weekly weather data.
2. can display state information
3. can change the background image according to day/night time call
4. weather icons can be more dynamic for day/night time duration
5. can be fully responsive structure 