import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-weather',
  templateUrl: './weather.component.html',
  styleUrls: ['./weather.component.css']
})
export class WeatherComponent implements OnInit {

  screenDayBgImg = 'assets/images/weatherDay_bg.jpg';
  screenNightBgImg = 'assets/images/weather_bg.jpg';
  topCardWeaImg = 'assets/images/weather-icons/day.svg';

  weatherData: any;
  time: any;
  data: any;
  city: any;
  main:any;
  wind: any;
  weather: any;
  clouds: any;
  dt_txt: any;

  constructor() { }

  ngOnInit(): void {
    this.getWeatherData();
    
  }

  async getWeatherData(){
    // let data = JSON.parse('{"coord":{"lon":73.8553,"lat":18.5196},"weather":[{"id":800,"main":"Clear","description":"clear sky","icon":"01d"}],"base":"stations","main":{"temp":306.2,"feels_like":304.21,"temp_min":306.2,"temp_max":306.2,"pressure":1012,"humidity":21,"sea_level":1012,"grnd_level":952},"visibility":10000,"wind":{"speed":3.98,"deg":312,"gust":4.58},"clouds":{"all":1},"dt":1618807478,"sys":{"country":"IN","sunrise":1618793085,"sunset":1618838536},"timezone":19800,"id":1259229,"name":"Pune","cod":200}')
    let response = await fetch('http://api.openweathermap.org/data/2.5/forecast?q=pune,india&APPID=09be0147a179fc491c2d2fd2aedc51e3');
    let data = await response.json();
    console.log(data);

    const {city} = data;
    const {main} = data.list[0];
    const {wind} = data.list[0];
    const weather = data.list[0].weather[0].main;
    const {clouds} = data.list[0];
    const {dt_txt} = data.list[0];
 
    
    this.city = city;
    this.main = main;
    this.wind = wind;
    this.weather = weather;
    this.clouds = clouds;
    this.dt_txt = dt_txt.split(" ")[0];


     this.setWeatherData(data);
    this.time = new Date().toLocaleTimeString();
  }

  setWeatherData(data: any){
    this.weatherData = data;
    this.weatherData.temp_celcius = (this.weatherData.list[0].main.temp - 273.15).toFixed(2);
    this.weatherData.temp_min = (this.weatherData.list[0].main.temp_min - 273.15).toFixed(0);
    this.weatherData.temp_max = (this.weatherData.list[0].main.temp_max - 273.15).toFixed(0);
    this.weatherData.temp_feels_like = (this.weatherData.list[0].main.feels_like - 273.15).toFixed(0);
    // this.weatherData.datetime = (this.weatherData.list[0].dt_txt);
    // this.weatherData.currentweather = (this.weatherData.list[0].weather[0].main);

    this.weatherData.day1Max = (this.weatherData.list[7].main.temp_max - 273.15).toFixed(0);
    this.weatherData.day1Min = (this.weatherData.list[7].main.temp_min - 273.15).toFixed(0);
    this.weatherData.day1datetime = (this.weatherData.list[7].dt_txt.split(" ")[0]);
    this.weatherData.day1weather = (this.weatherData.list[7].weather[0].main);

    this.weatherData.day2Max = (this.weatherData.list[15].main.temp_max - 273.15).toFixed(0);
    this.weatherData.day2Min = (this.weatherData.list[15].main.temp_min - 273.15).toFixed(0);
    this.weatherData.day2datetime = (this.weatherData.list[15].dt_txt.split(" ")[0]);
    this.weatherData.day2weather = (this.weatherData.list[15].weather[0].main);

    this.weatherData.day3Max = (this.weatherData.list[23].main.temp_max - 273.15).toFixed(0);
    this.weatherData.day3Min = (this.weatherData.list[23].main.temp_min - 273.15).toFixed(0);
    this.weatherData.day3datetime = (this.weatherData.list[23].dt_txt.split(" ")[0]);
    this.weatherData.day3weather = (this.weatherData.list[23].weather[0].main);

    this.weatherData.day4Max = (this.weatherData.list[31].main.temp_max - 273.15).toFixed(0);
    this.weatherData.day4Min = (this.weatherData.list[31].main.temp_min - 273.15).toFixed(0);
    this.weatherData.day4datetime = (this.weatherData.list[31].dt_txt.split(" ")[0]);
    this.weatherData.day4weather = (this.weatherData.list[31].weather[0].main);

    this.weatherData.day5Max = (this.weatherData.list[39].main.temp_max - 273.15).toFixed(0);
    this.weatherData.day5Min = (this.weatherData.list[39].main.temp_min - 273.15).toFixed(0);
    this.weatherData.day5datetime = (this.weatherData.list[39].dt_txt.split(" ")[0]);
    this.weatherData.day5weather = (this.weatherData.list[39].weather[0].main);

  }

}
